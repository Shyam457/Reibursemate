// ExpenseDayModel.java
package com.example.reimbursemate;

public class ExpenseDayModel {
    private String date;
    private double totalAmount;

    public ExpenseDayModel(String date, double totalAmount) {
        this.date = date;
        this.totalAmount = totalAmount;
    }

    public String getDate() {
        return date;
    }

    public double getTotalAmount() {
        return totalAmount;
    }
}
