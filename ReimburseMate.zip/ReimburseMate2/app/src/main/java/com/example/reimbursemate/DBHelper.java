package com.example.reimbursemate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "UserDB";
    private static final int DATABASE_VERSION =5;

    private static final String TABLE_USERS = "users";

    private static final String TABLE_EXPENSE="expenses";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PHONE = "phone";

    private static final String COLUMN_AMOUNT = "c_amount";
    private static final String COLUMN_NOTE = "c_note";

    private static final String TABLE_REIMBURSEMENTS = "reimbursements";

    private static final String COLUMN_EMPLOYEE_NAME = "employee_name";
    private static final String COLUMN_EXPENSE_MONTH = "expense_month";
    private static final String COLUMN_TOTAL_AMOUNT = "total_amount";

    private static final String COLUMN_ROLE = "role";

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + "("
                + COLUMN_USERNAME + " TEXT PRIMARY KEY,"
                + COLUMN_ID + " TEXT,"
                + COLUMN_PASSWORD + " TEXT,"
                + COLUMN_PHONE + " TEXT,"
                + COLUMN_ROLE + " TEXT" + ")";

        db.execSQL(CREATE_USERS_TABLE);


        String CREATE_EXPENSE_TABLE = "CREATE TABLE " + TABLE_EXPENSE + "("
                + COLUMN_AMOUNT + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_NOTE + " TEXT,"
                + COLUMN_EMPLOYEE_NAME + " TEXT,"
                + "date TEXT" + ")";
        db.execSQL(CREATE_EXPENSE_TABLE);

        String CREATE_REIMBURSEMENTS_TABLE = "CREATE TABLE " + TABLE_REIMBURSEMENTS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_EMPLOYEE_NAME + " TEXT,"
                + COLUMN_EXPENSE_MONTH + " TEXT,"
                + COLUMN_TOTAL_AMOUNT + " REAL)";
        db.execSQL(CREATE_REIMBURSEMENTS_TABLE);
    }

    public Cursor getMonthlySummaryData() {
        SQLiteDatabase db = this.getReadableDatabase();

        // Assuming you have a column 'date' in your 'expenses' table
        String query = "SELECT strftime('%Y-%m', date) AS month, SUM(" + COLUMN_AMOUNT + ") AS total_amount " +
                "FROM " + TABLE_EXPENSE +
                " GROUP BY strftime('%Y-%m', date)";

        return db.rawQuery(query, null);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if it exists
        if (oldVersion < 2) {
            // Add the role column
            db.execSQL("ALTER TABLE users ADD COLUMN role TEXT;");
        }
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_EXPENSE);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REIMBURSEMENTS);
        // Create tables again
        onCreate(db);
    }

    // Method to add a new user
    public long addUser(String username, String id, String phone, String password, String role) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_ID,id);
        values.put(COLUMN_PHONE,phone);
        values.put(COLUMN_PASSWORD, password);
        values.put(COLUMN_ROLE, role);
        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result;
    }


    public UserInfo validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_ID, COLUMN_USERNAME,COLUMN_PHONE,COLUMN_PASSWORD, COLUMN_ROLE};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        UserInfo userInfo = new UserInfo();
        if (cursor.moveToFirst()) {
            userInfo.setValid(true);
            userInfo.setId(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ID)));
            userInfo.setUsername(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_USERNAME)));
            userInfo.setPhone(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_PHONE)));
            userInfo.setRole(cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_ROLE)));
        } else {
            userInfo.setValid(false);
        }

        cursor.close();
        db.close();

        return userInfo;
    }




    public long insertExpenseDetails(String amount, String note,String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_AMOUNT, amount);
        values.put(COLUMN_NOTE, note);
        values.put("date", date); // Add date column
        return db.insert(TABLE_EXPENSE, null, values);
    }

    public Cursor getExpenseDetails() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_EXPENSE;
        return db.rawQuery(query, null);
    }

    public ArrayList<ReimbursementModel> getReimbursements() {
        ArrayList<ReimbursementModel> reimbursements = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        // Assuming you have a column 'date' in your 'expenses' table
        String query = "SELECT " + COLUMN_EMPLOYEE_NAME + ", " +
                "strftime('%Y-%m', date) AS " + COLUMN_EXPENSE_MONTH + ", " +
                "SUM(" + COLUMN_AMOUNT + ") AS " + COLUMN_TOTAL_AMOUNT +
                " FROM " + TABLE_EXPENSE +
                " GROUP BY " + COLUMN_EMPLOYEE_NAME + ", strftime('%Y-%m', date)";

        Cursor cursor = db.rawQuery(query, null);

        while (cursor.moveToNext()) {
            String employeeName = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EMPLOYEE_NAME));
            String expenseMonth = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EXPENSE_MONTH));
            float totalAmount = cursor.getFloat(cursor.getColumnIndexOrThrow(COLUMN_TOTAL_AMOUNT));


            ReimbursementModel reimbursement = new ReimbursementModel(employeeName, expenseMonth, totalAmount);
            reimbursements.add(reimbursement);
        }

        cursor.close();
        db.close();

        return reimbursements;
    }
}
