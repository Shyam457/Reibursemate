package com.example.reimbursemate;

import android.app.Application;

public class MyApplication extends Application {
    public static DBHelper dbHelper;
    public static SessionManager sessionManager;

    @Override
    public void onCreate() {
        super.onCreate();
        dbHelper = new DBHelper(this);
        sessionManager = new SessionManager(this);
    }
}
