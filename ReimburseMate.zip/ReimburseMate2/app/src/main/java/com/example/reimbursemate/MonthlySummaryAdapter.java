// MonthlySummaryAdapter.java
package com.example.reimbursemate;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MonthlySummaryAdapter extends RecyclerView.Adapter<MonthlySummaryAdapter.ViewHolder> {

    private List<ExpenseDayModel> expenseDays;

    public void setExpenseDays(List<ExpenseDayModel> expenseDays) {
        this.expenseDays = expenseDays;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_daily_expense, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ExpenseDayModel expenseDay = expenseDays.get(position);
        holder.textDate.setText(expenseDay.getDate());
        holder.textTotalAmount.setText(String.valueOf(expenseDay.getTotalAmount()));
    }

    @Override
    public int getItemCount() {
        return expenseDays != null ? expenseDays.size() : 0;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textDate;
        TextView textTotalAmount;

        ViewHolder(View itemView) {
            super(itemView);
            textDate = itemView.findViewById(R.id.textDate);
            textTotalAmount = itemView.findViewById(R.id.textTotalAmount);
        }
    }
}
