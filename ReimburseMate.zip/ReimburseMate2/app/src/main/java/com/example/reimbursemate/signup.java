package com.example.reimbursemate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class signup extends AppCompatActivity {
    EditText name;
    EditText create_password;
    EditText phone;
    EditText confirm_password;
    EditText create_username;
    CheckBox checkBox;
    Button register;
    DBHelper dbHelper;
    EditText emp_id;
    Spinner roleSpinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        emp_id = findViewById(R.id.editTextID);
        name = findViewById(R.id.editTextText);
        phone = findViewById(R.id.editTextPhone);
        create_password = findViewById(R.id.editTextText2);
        confirm_password = findViewById(R.id.editTextText3);
        create_username = findViewById(R.id.editTextTextEmailAddress2) ;
        checkBox = findViewById(R.id.checkBox);
        register = findViewById(R.id.button);
        dbHelper = new DBHelper(this);
        roleSpinner = findViewById(R.id.roleSpinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.roles_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        roleSpinner.setAdapter(adapter);



        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked){
                    register.setVisibility(View.VISIBLE);
                }
                else{
                    register.setVisibility(View.INVISIBLE);
                }
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredName = name.getText().toString();
                String enteredPhone = phone.getText().toString();
                String enteredPassword = create_password.getText().toString();
                String enteredConfirmPassword = confirm_password.getText().toString();
                String enteredID = emp_id.getText().toString();
                String enteredRole = roleSpinner.getSelectedItem().toString();
                if (enteredName.isEmpty() || enteredPhone.isEmpty() || enteredPassword.isEmpty() ||
                        enteredConfirmPassword.isEmpty() || enteredID.isEmpty()) {
                    Toast.makeText(signup.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                } else if (!enteredPassword.equals(enteredConfirmPassword)) {
                    Toast.makeText(signup.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
                } else {
                    String userRole = enteredRole;
                    long result = dbHelper.addUser(enteredName, enteredID,enteredPhone, enteredPassword,enteredRole);
                    if (result != -1) {
                        // Registration was successful
                        Toast.makeText(signup.this, "Registration successful", Toast.LENGTH_SHORT).show();
                        Log.d("Debug", "Name: " + enteredName);
                        Intent loginintent = new Intent(signup.this, login.class);
                        loginintent.putExtra("userRole",userRole);
                        startActivity(loginintent);

                    } else {
                        Toast.makeText(signup.this, "Registration failed", Toast.LENGTH_SHORT).show();
                    }
                }

            }
        });




    }
}

