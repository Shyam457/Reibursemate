package com.example.reimbursemate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.HashMap;

public class login extends AppCompatActivity {
    DBHelper dbHelper;
    private SessionManager sessionManager;
    EditText usernameEditText, passwordEditText;
    Button loginButton;
    Button signup_button;
    Spinner roleSpinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        dbHelper = new DBHelper(this);
        sessionManager = MyApplication.sessionManager;

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        roleSpinner = findViewById(R.id.roleSpinner);
        String roles[] = {"company","employee"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, roles);
        roleSpinner.setAdapter(adapter);

        loginButton = findViewById(R.id.loginButton);
        signup_button = findViewById(R.id.signup);
        signup_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i2 = new Intent(login.this, signup.class);
                startActivity(i2);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String enteredUsername = usernameEditText.getText().toString();
                String enteredPassword = passwordEditText.getText().toString();
                String selectedRole = roleSpinner.getSelectedItem().toString();

                if (enteredUsername.isEmpty() || enteredPassword.isEmpty()) {
                    Toast.makeText(login.this, "Please enter both username and password", Toast.LENGTH_SHORT).show();
                } else {
                    UserInfo userInfo = dbHelper.validateUser(enteredUsername, enteredPassword);

                    if (userInfo.isValid()) {

                        String userRole = userInfo.getRole();

                        // Check if the selected role matches the user's role
                        if (selectedRole.equals(userRole)) {
                            if("company".equals(userRole)) {
                                Intent company_intent = new Intent(login.this, Company_Dashboard.class);
                                startActivity(company_intent);
                            } else if ("employee".equals(userRole)) {
                                Intent employee_intent = new Intent(login.this, Dashboard.class);
                                startActivity(employee_intent);
                            }

                        } else {
                            Toast.makeText(login.this, "Invalid Role for the user", Toast.LENGTH_SHORT).show();
                        }
                        Toast.makeText(login.this, "Welcome " + enteredUsername, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(login.this, "Invalid Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        HashMap<String, String> userDetails = sessionManager.getUserDetails();
        if (userDetails.get(SessionManager.KEY_USERNAME) != null) {
            // User is already logged in, navigate to the dashboard
            String userRole = userDetails.get(SessionManager.KEY_ROLE);
            navigateToDashboard(userRole);
            finish();  // Close the login activity
        }
    }

    private void navigateToDashboard(String userRole) {
        if ("company".equals(userRole)) {
            startActivity(new Intent(login.this, Company_Dashboard.class));
        } else if ("employee".equals(userRole)) {
            startActivity(new Intent(login.this, Dashboard.class));
        }

    }
}
