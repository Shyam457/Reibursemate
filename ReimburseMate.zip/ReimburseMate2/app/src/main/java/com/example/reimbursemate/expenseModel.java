package com.example.reimbursemate;

import android.os.Parcel;
import android.os.Parcelable;

public class expenseModel implements Parcelable {
    public String amount_1;
    public String note_1;




    public expenseModel(String amount_1, String note_1) {
        this.amount_1 = amount_1;
        this.note_1 = note_1;


    }




    protected expenseModel(Parcel in) {
        note_1 = in.readString();

        amount_1 = in.readString();

    }

    public static final Creator<expenseModel> CREATOR = new Creator<expenseModel>() {
        @Override
        public expenseModel createFromParcel(Parcel in) {
            return new expenseModel(in);
        }

        @Override
        public expenseModel[] newArray(int size) {
            return new expenseModel[size];
        }
    };



    public String getAmount_1() {

        return amount_1;
    }

    public String getNote_1() {

        return note_1;
    }




    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(amount_1);
        dest.writeString(note_1);

    }
}
