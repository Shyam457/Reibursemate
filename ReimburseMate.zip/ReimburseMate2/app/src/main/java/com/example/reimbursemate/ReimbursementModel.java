package com.example.reimbursemate;

public class ReimbursementModel {
    private String employeeName;
    private String expenseMonth;
    private float totalAmount;

    public ReimbursementModel(String employeeName, String expenseMonth, float totalAmount) {
        this.employeeName = employeeName;
        this.expenseMonth = expenseMonth;
        this.totalAmount = totalAmount;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public String getExpenseMonth() {
        return expenseMonth;
    }

    public float getTotalAmount() {
        return totalAmount;
    }
}
