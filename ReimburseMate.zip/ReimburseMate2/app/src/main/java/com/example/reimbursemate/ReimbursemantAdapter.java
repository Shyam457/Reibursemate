package com.example.reimbursemate;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ReimbursemantAdapter extends RecyclerView.Adapter<ReimbursemantAdapter.ViewHolder>{
    private ArrayList<ReimbursementModel> reimbursements;

    public ReimbursemantAdapter(ArrayList<ReimbursementModel> reimbursements) {
        this.reimbursements = reimbursements;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_reimbursement, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ReimbursementModel reimbursement = reimbursements.get(position);

        holder.textViewEmployeeName.setText("Employee: " + reimbursement.getEmployeeName());
        holder.textViewExpenseMonth.setText("Month: " + reimbursement.getExpenseMonth());
        holder.textViewTotalAmount.setText("Total Amount: " + reimbursement.getTotalAmount());
    }

    @Override
    public int getItemCount() {
        return reimbursements.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewEmployeeName;
        TextView textViewExpenseMonth;
        TextView textViewTotalAmount;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewEmployeeName = itemView.findViewById(R.id.textViewEmployeeName);
            textViewExpenseMonth = itemView.findViewById(R.id.textViewExpenseMonth);
            textViewTotalAmount = itemView.findViewById(R.id.textViewTotalAmount);
        }
    }
}
