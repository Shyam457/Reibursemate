package com.example.reimbursemate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class Dashboard extends AppCompatActivity {
    LineChart lineChart;
    TextView textView;
    RecyclerView recyclerView;
    DBHelper dbHelper;
    RecyclerAdapter adapter;
    List<Entry> dataValues;
    Button next;
    Button logout;
    SessionManager sessionManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        sessionManager = new SessionManager(getApplicationContext());
        textView = findViewById(R.id.textView);
        recyclerView = findViewById(R.id.recyclerView);
        lineChart = findViewById(R.id.line_chart);
        next = findViewById(R.id.next);
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Dashboard.this, MonthlySummary.class);
                startActivity(i);
            }
        });
        logout = findViewById(R.id.btnLogout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sessionManager.logoutUser();
                startActivity(new Intent(Dashboard.this, login.class));
                finish();
            }
        });

        dataValues = new ArrayList<>();

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        dbHelper = new DBHelper(this);

        // Initialize the lineChart
        lineChart = findViewById(R.id.line_chart);

        // Set the adapter to the RecyclerView
        adapter = new RecyclerAdapter(Dashboard.this, new ArrayList<>());
        recyclerView.setAdapter(adapter);

        FloatingActionButton add_button = findViewById(R.id.addbutton);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExpenseInputDialog();
            }
        });
    }
        private void showExpenseInputDialog(){
            Dialog dialog = new Dialog(Dashboard.this);
            dialog.setContentView(R.layout.add_expense);

            EditText edtAmount = dialog.findViewById(R.id.edtamt);
            EditText editNote = dialog.findViewById(R.id.editnote);

            Button btnAction = dialog.findViewById(R.id.btnAction);
            btnAction.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String amount = edtAmount.getText().toString();
                    String note = editNote.getText().toString();
                    String currentDate = getCurrentDate(); // You need to implement this method

                    if (!amount.isEmpty() && !note.isEmpty()) {
                        dbHelper.insertExpenseDetails(amount, note, currentDate);
                        loadExpenseDetailsFromDatabase();
                        updateLineChart();
                        dialog.dismiss();
                    } else {
                        Toast.makeText(Dashboard.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                    }
                }
            });

            dialog.show();
        }



        private String getCurrentDate(){

            return "2024-01-19";
        }


    private void loadExpenseDetailsFromDatabase() {
        Cursor cursor = dbHelper.getExpenseDetails();

        while (cursor.moveToNext()) {
            String amount_2 = cursor.getString(cursor.getColumnIndexOrThrow("c_amount"));
            String note_2 = cursor.getString(cursor.getColumnIndexOrThrow("c_note"));

            expenseModel expense = new expenseModel(amount_2, note_2);
            adapter.addExpense(expense);
        }
    }

    private void updateLineChart() {
        LineDataSet lineDataSet = new LineDataSet(dataValues(), "Data Set");
        ArrayList<ILineDataSet> dataSets = new ArrayList<>();
        dataSets.add(lineDataSet);
        LineData data = new LineData(dataSets);
        lineChart.setData(data);
        lineChart.invalidate();
    }

    private List<Entry> dataValues() {
        ArrayList<Entry> dataValue = new ArrayList<>();
        dataValue.add(new Entry(0, 10));
        dataValue.add(new Entry(1, 15));
        dataValue.add(new Entry(2, 20));
        dataValue.add(new Entry(3, 25));
        dataValue.add(new Entry(4, 30));
        return dataValue;
    }
}
