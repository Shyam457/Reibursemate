package com.example.reimbursemate;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class Company_Dashboard extends AppCompatActivity {
    private RecyclerView recyclerView;
    private ReimbursemantAdapter reimbursementAdapter;
    private DBHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_company_dashboard);
        dbHelper = new DBHelper(this);

        recyclerView = findViewById(R.id.recyclerViewReimbursements);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadReimbursements();
    }
    private void loadReimbursements() {
        // Fetch reimbursements from the database
        ArrayList<ReimbursementModel> reimbursements = dbHelper.getReimbursements();

        // Initialize the adapter with the data
        reimbursementAdapter = new ReimbursemantAdapter(reimbursements);
        recyclerView.setAdapter(reimbursementAdapter);
    }
}