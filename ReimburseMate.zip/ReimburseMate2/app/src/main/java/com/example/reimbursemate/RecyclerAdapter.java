package com.example.reimbursemate;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerAdapter.ViewHolder> {
    ArrayList<expenseModel> expense_array;
    private OnItemClickListener itemClickListener;

    Context context;

    public interface OnItemClickListener{
        void onItemClick(expenseModel position);


    }


    RecyclerAdapter (Context context, ArrayList<expenseModel> expense_array){
        this.context= context;
        this.expense_array = expense_array;
    }
    public void setOnItemClickListener(OnItemClickListener listener){
        this.itemClickListener = listener;
    }

    public void addExpense(expenseModel newCar) {
        expense_array.add(newCar);
        notifyDataSetChanged(); // Notify the adapter that the dataset has changed
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.expense_row,parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {


        expenseModel current_position = expense_array.get(position);
        holder.txtAmount.setText(current_position.amount_1);
        holder.txtNote.setText(current_position.note_1);



        holder.l1row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int current_position = holder.getAdapterPosition();
                Dialog dialog  = new Dialog(context);
                dialog.setContentView(R.layout.add_expense);
                expenseModel clickedCar = expense_array.get(current_position);
                Intent i =  new Intent(context, ExpenseSumary.class);
                i.putExtra("amount_1", clickedCar.amount_1);
                i.putExtra("note_1", clickedCar.note_1);

                if(itemClickListener != null){
                    itemClickListener.onItemClick(clickedCar);
                }


            }
        });


        holder.l1row.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                int current_position = holder.getAdapterPosition();

                AlertDialog.Builder builder = new AlertDialog.Builder(context)
                        .setTitle("Delete Expense")
                        .setMessage("Are you sure you want to delete?")
                        .setIcon(R.drawable.baseline_delete_24)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                expense_array.remove(current_position);
                                notifyItemRemoved(current_position);
                            }
                        })
                        .setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                            }
                        });
                builder.show();


                return true ;
            }
        });

    }

    @Override
    public int getItemCount() {
        if(expense_array != null) {

            return expense_array.size();
        }else {
            return 0;
        }
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView txtAmount, txtNote;
        LinearLayout l1row;
        public ViewHolder(View itemView){
            super(itemView);
            txtAmount = itemView.findViewById(R.id.txtAmount);
            txtNote  = itemView.findViewById(R.id.txtNote);

            l1row = itemView.findViewById(R.id.l1row);


        }
    }

}
