package com.example.reimbursemate;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.database.Cursor;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MonthlySummary extends AppCompatActivity {
    RecyclerView recyclerViewMonthlySummary;
    DBHelper dbHelper;
    MonthlySummaryAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monthly_summary);
        recyclerViewMonthlySummary = findViewById(R.id.recyclerViewMonthlySummary);
        dbHelper = new DBHelper(this);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerViewMonthlySummary.setLayoutManager(layoutManager);

        adapter = new MonthlySummaryAdapter();
        recyclerViewMonthlySummary.setAdapter(adapter);

        loadMonthlySummaryFromDatabase();
    }

    private void loadMonthlySummaryFromDatabase() {

        List<ExpenseDayModel> expenseDays = getMonthlySummaryData();
        adapter.setExpenseDays(expenseDays);
    }



    private List<ExpenseDayModel> getMonthlySummaryData() {
        Cursor cursor = dbHelper.getMonthlySummaryData();
        return parseCursorToMonthlySummaryModels(cursor);
    }

    private List<ExpenseDayModel> parseCursorToMonthlySummaryModels(Cursor cursor) {
        List<ExpenseDayModel> monthlySummaryList = new ArrayList<>();

        while (cursor.moveToNext()) {
            String month = cursor.getString(cursor.getColumnIndexOrThrow("month"));
            int totalAmount = cursor.getInt(cursor.getColumnIndexOrThrow("total_amount"));

            ExpenseDayModel summary = new ExpenseDayModel(month, totalAmount);
            monthlySummaryList.add(summary);
        }

        cursor.close();
        return monthlySummaryList;
    }
    }
